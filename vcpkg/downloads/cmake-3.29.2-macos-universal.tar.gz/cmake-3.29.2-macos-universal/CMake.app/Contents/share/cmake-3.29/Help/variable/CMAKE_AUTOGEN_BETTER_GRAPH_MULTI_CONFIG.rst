CMAKE_AUTOGEN_BETTER_GRAPH_MULTI_CONFIG
---------------------------------------

.. versionadded:: 3.29

This variable is used to initialize the
:prop_tgt:`AUTOGEN_BETTER_GRAPH_MULTI_CONFIG` property on all targets as they
are created.  See that target property for additional information.

By default ``CMAKE_AUTOGEN_BETTER_GRAPH_MULTI_CONFIG`` is unset.
