CMAKE_ANDROID_EXCEPTIONS
------------------------

.. versionadded:: 3.20

When :ref:`Cross Compiling for Android with the NDK`, this variable may be set
to specify whether exceptions are enabled.
