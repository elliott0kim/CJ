CMAKE_ANDROID_JAR_DIRECTORIES
-----------------------------

.. versionadded:: 3.4

Default value for the :prop_tgt:`ANDROID_JAR_DIRECTORIES` target property.
See that target property for additional information.
