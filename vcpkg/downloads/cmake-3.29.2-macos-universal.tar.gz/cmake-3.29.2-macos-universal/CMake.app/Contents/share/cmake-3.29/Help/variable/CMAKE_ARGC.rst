CMAKE_ARGC
----------

Number of command line arguments passed to CMake in script mode.

When run in :ref:`-P <Script Processing Mode>` script mode, CMake sets this
variable to the number of command line arguments.  See also
:variable:`CMAKE_ARGV0`, ``1``, ``2`` ...
